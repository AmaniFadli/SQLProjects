package ProyectoC;

import java.util.*;

import org.bson.Document;

import com.mongodb.MongoCommandException;
import com.mongodb.MongoException;
import com.mongodb.client.*;
import com.mongodb.client.model.Filters;
import static com.mongodb.client.model.Updates.*;

public class Collection {

public static void MongoPojoCreate(MongoDatabase database) {
		
		Scanner reader = new Scanner(System.in);
		
		String respuesta;
		
		String id;
		String nombre;
		int existencias;
		int precio;
		
		String name;
		String email;
		int telefono;	
				
		MongoCollection<Videojuegos> collection = database.getCollection("VideojuegosObject", Videojuegos.class);
		
		try {
			
			do {
				
				System.out.println("Ingresa un Videojuego: ");
				System.out.println("1. id: ");
					id = reader.nextLine();			
					//reader.nextLine();
				System.out.println("2. Nombre: ");
					nombre = reader.nextLine();
				System.out.println("3. Existencias: ");
					existencias = reader.nextInt();
					reader.nextLine();
				System.out.println("4. Precio: ");
					precio = reader.nextInt();
					reader.nextLine();
				
				System.out.println("Ingresa el diseñador: ");				
				System.out.println("1. Nombre: ");
					name = reader.nextLine();					
				System.out.println("2. Email: ");
					email = reader.nextLine();
				System.out.println("3. Telefono: ");
					telefono = reader.nextInt();
					reader.nextLine();
	
				Diseñador d = new Diseñador (name, email, telefono);
				
				Videojuegos v = new Videojuegos(id, nombre, d, existencias, precio);		
			
				collection.insertOne(v);
			
				System.out.println("Quieres añadir otro videojuego? [S/N]");
				
				respuesta = reader.nextLine();
				
			}while(respuesta.charAt(0) == 's' || respuesta.charAt(0) == 'S');
			
			System.out.println("Hasta la próxima...");
			
			
		} catch(MongoException e) {
			e.printStackTrace();
		}
	}
	
	public static void MongoPojoRead(MongoDatabase database) {
		
		try {
			
			MongoCollection<Videojuegos> collection = database.getCollection("VideojuegosObject", Videojuegos.class);
			MongoCursor<Videojuegos> collect = collection.find().iterator();
			
			while(collect.hasNext()) {
				
				Videojuegos v = collect.next();
				
				System.out.println(v.toString());			
			}
			
			
		}catch(MongoException e) {
			e.printStackTrace();
		}
	}
	
	public static void MongoPojoUpdate(MongoDatabase database) {
		
		Scanner reader = new Scanner(System.in);
		int opcion;
		String respuesta;
		
		try {
			
			MongoCollection<Videojuegos> collection = database.getCollection("VideojuegosObject", Videojuegos.class);
			
			System.out.println("Iniciando la modificación...");
			System.out.println("Indica el id del videojuego a modificar");
			String id = reader.next();
					
			Videojuegos v = collection.find(Filters.eq("_id", id)).first();			
				        
				if (v!= null) {
					
					do {	
						System.out.println("Elige la opción que quieres modificar: ");
						System.out.println("Opción 1. Nombre del videojuego: ");
						System.out.println("Opción 2. Existencias del videojuego: ");
						System.out.println("Opción 3. Precio del videojuego: ");
						System.out.println("Opción 4. Diseñador: ");
						
						opcion = reader.nextInt();
						reader.nextLine();
						
						switch(opcion) {
						
							case 1:
								
								String nombre;
								
								System.out.println("Ingresa el nombre nuevo: ");
									nombre = reader.nextLine();											
									collection.updateOne(Filters.eq("_id", id), set("nombre", nombre));
								break;
							case 2:
								
								int existencias;
								
								System.out.println("Ingresa las nuevas existencias: ");
									existencias = reader.nextInt();
									reader.nextLine();
									collection.updateOne(Filters.eq("_id", id), set("existencias", existencias));
									
								break;
							case 3:
								
								int precio;
								
								System.out.println("Ingresa el nuevo precio: ");
									precio = reader.nextInt();
									reader.nextLine();
									collection.updateOne(Filters.eq("_id", id), set("precio", precio));
								
								break;
							case 4:
								Diseñador d = v.getDiseñador();
								
								String name;
								String email;
								int telefono;
								
								System.out.println("Ingresa el nuevo nombre del diseñador: ");
									name = reader.nextLine();
									d.setNombre(name);										
								System.out.println("Ingresa el nuevo email del diseñador: ");
									email = reader.nextLine();
									d.setEmail(email);										
								System.out.println("Ingresa el nuevo teléfono del diseñador: ");
									telefono = reader.nextInt();
									reader.nextLine();
									d.setTelefono(telefono);									
									v.setDiseñador(d);
									collection.updateOne(Filters.eq("_id", id), set("diseñador", d));
									break;
							default:
								System.out.println("Elige una opción correcta");
								break;
						}
						
						System.out.println("Quieres modificar otra característica del videojuego(s-si, n-no)");
						
							respuesta = reader.next();
						
					}while (respuesta.charAt(0) == 's' || respuesta.charAt(0) == 'S');								
			}	
		}catch(MongoException e) {
			e.printStackTrace();
		}		
	}

	public static void MongoPojoDelete(MongoDatabase database) {		
		Scanner input = new Scanner(System.in);

		try {

			MongoCollection < Document > collection = database.getCollection("VideojuegosObject");

			System.out.println("Escribe la id del videojuego que quieres borrar.");
			String id = input.nextLine();	
			collection.deleteOne(Filters.eq("_id", id));	
			System.out.println("Document deleted successfully...");
		} catch (MongoException e) {			e.getStackTrace();

		}	
	}
}
