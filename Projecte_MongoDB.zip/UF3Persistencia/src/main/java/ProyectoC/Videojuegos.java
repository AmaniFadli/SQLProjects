package ProyectoC;

public class Videojuegos {

	String id;
	String nombre;
	Diseñador diseñador;
	int existencias;
	int precio;
	
	public Videojuegos() {
		
	}
	public Videojuegos(String id, String nombre, Diseñador diseñador, int existencias, int precio) {
		this.id = id;
		this.nombre = nombre;
		this.diseñador = diseñador;
		this.existencias = existencias;
		this.precio = precio;
	}


	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Diseñador getDiseñador() {
		return diseñador;
	}
	public void setDiseñador(Diseñador diseñador) {
		this.diseñador = diseñador;
	}
	public int getExistencias() {
		return existencias;
	}
	public void setExistencias(int existencias) {
		this.existencias = existencias;
	}
	public int getPrecio() {
		return precio;
	}
	public void setPrecio(int precio) {
		this.precio = precio;
	}
	@Override
	public String toString() {
		return "Videojuego [id=" + id + ", nombre=" + nombre + ", diseñador=" + diseñador + ", existencias="
				+ existencias + ", precio=" + precio + "]";
	}
	
	
}
