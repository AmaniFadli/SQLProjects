package ProyectoC;

import java.util.Scanner;

import org.bson.Document;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.MongoException;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class Main {

	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in);
		
		String connectionString = "mongodb+srv://eladio:eladioalbertamani@uf3persistencia.1memkp2.mongodb.net/?retryWrites=true&w=majority";
		
		ServerApi serverApi = ServerApi.builder().version(ServerApiVersion.V1).build();		
		
		MongoClientSettings settings = MongoClientSettings.builder().applyConnectionString(new ConnectionString(connectionString)).serverApi(serverApi).build();	
		
		CodecRegistry pojoCodecRegistry = CodecRegistries.fromRegistries(MongoClientSettings.getDefaultCodecRegistry(),CodecRegistries.fromProviders(PojoCodecProvider.builder().automatic(true).build()));
		
		int opcion;
		int rep = 0;
		try (MongoClient mongoClient = MongoClients.create(settings)){
			
			try {
								
				MongoDatabase database = mongoClient.getDatabase("uf3persistencia");
				database = database.withCodecRegistry(pojoCodecRegistry);
				database.runCommand(new Document("ping", 1));
				System.out.println("Pinged your deployment. You successfully connected to MongoDB!");
				
				
				do {
					
				System.out.println("Elige la opción: ");
				System.out.println("Opción.1 Crear videojuego");
				System.out.println("Opción.2 Leer todos los videojuegos");
				System.out.println("Opción.3 Actualizar videojuego");
				System.out.println("Opción.4 Borrar videojuego");
				
				opcion = reader.nextInt();
				reader.nextLine();	
				
				switch(opcion) {
					
						case 1:
							Collection.MongoPojoCreate(database);
							break;
						case 2:
							Collection.MongoPojoRead(database);
							break;
						case 3:
							Collection.MongoPojoUpdate(database);
							break;
						case 4:
							Collection.MongoPojoDelete(database);
							break;
						default:
							System.out.println("Elige una opción correcta");
							break;				
					}
				
				 System.out.println("Quieres volver al menú? 1-SI 2-NO" );

	                rep = reader.nextInt();
	                reader.nextLine();

	             }while(rep == 1);			
				
			}catch (MongoException e) {
	            e.printStackTrace();
	        }					
		}catch (MongoException e) {
            e.printStackTrace();
        }	
	}
}
