package Proyectos;

import java.util.*;

import org.bson.Document;

import com.mongodb.MongoCommandException;
import com.mongodb.client.*;
import com.mongodb.client.model.Filters;


public class Collection {
	
	public static void insertDocument(MongoDatabase database) {
		Scanner input = new Scanner(System.in);
		
		try {
			int rep = 0, o = 0;
			do {
				
			
				System.out.println("Añadiendo cliente . . .");
				
				MongoCollection < Document > collection = database.getCollection("Clientes");
				ArrayList<Document> facts = new ArrayList<Document>();
				
				System.out.println("Creando el nuevo documento...");
				
				
				//cliente
				System.out.println("Añadiendo cliente...");
				
				System.out.println("Introduce el NIF");
				String nif = input.next();
				
				System.out.println("Introduce el nombre");
				String nom = input.next();
				
				System.out.println("Introduce el Telefono");
				int tel = input.nextInt();
				
				Document d1 = new Document("_id",nif);
				d1.append("Nombre", nom);
				d1.append("Telefono", tel);
				
				 
				
				System.out.println("Quieres añadir una factura al cliente? 1-SI 2-NO");
				int opc = input.nextInt();
				
				if(opc == 1) {
					do {
						System.out.println("Añadiendo Factura...");
						System.out.println("Introduce el codigo de la Factura");
						int cf = input.nextInt();
						input.nextLine();
						
						System.out.println("Introduce el nombre del producto");
						String nomP = input.next();
						
						System.out.println("Introduce el precio");
						int quant = input.nextInt();
						
						Document d2 = new Document("_id", "Codigo Producto: " + cf);
						d2.append("NombreProducto", nomP);
						d2.append("Precio", quant);
						
						facts.add(d2);
						
						System.out.println("Quieres añadir otra Factura? 1-SI 2-NO");
						o = input.nextInt();
					}while(o == 1);
					
					d1.append("Facturas", facts);
					collection.insertOne(d1);
				}
				else {
					d1.append("Facturas", null);
					collection.insertOne(d1);
				}
				System.out.println("¡Cliente añadido!");
				System.out.println("Quieres volver a insertar otro Cliente? 1-SI, 2-NO");
				rep = input.nextInt();
				
			}while(rep == 1);
		}
		catch ( Exception e) {
            e . printStackTrace();
        }
	
	}

	public static void updateDocument(MongoDatabase database) {
		Scanner input = new Scanner(System.in);
		
		try {

	        MongoCollection < Document > collection = database.getCollection("Clientes");

	        System.out.println("Modificacion iniciada ...");
	        
	        System.out.println("Selecciona el NIF del Cliente que quieres modificar");
	        String nif = input.next();
	        System.out.println("Que quieres modiciar?:");
	        System.out.println("1 -> Nombre");
	        System.out.println("2 -> Numero de telefono");
	        
	        int o = input.nextInt();
	        
	        if(o == 1) {
	        	System.out.print("Inserta el nuevo nombre: ");
	        	String nom = input.next();
	        	 
	        	collection.updateOne(new Document("_id", nif),new Document("$set", new Document("Nombre", nom)));
	        }
	        else if(o == 2) {
	        	System.out.print("Inserta el nuevo numero: ");
	        	int tel = input.nextInt();
	        	 
	        	collection.updateOne(new Document("_id", nif),new Document("$set", new Document("Telefono", tel)));
	        }
	       
	        System.out.println("Modificacion terminada");
	        System.out.println();
		}		
		catch ( Exception e) {
			System.out.println("!!!!Error en la modificación!!!!");
            e . printStackTrace();
        }
	}

	public static void deleteCollection(MongoDatabase database) {
		Scanner input = new Scanner(System.in);

		try {

			MongoCollection < Document > collection = database.getCollection("Clientes");
			System.out.println("Escribe la IF/NIF del Cliente que quieres borrar.");
			String id = input.nextLine();			
			collection.deleteOne(Filters.eq("_id", id));
			System.out.println("Document deleted successfully...");
		} catch (Exception e) {
			e.getStackTrace();
		}

	}
	public static void printCollections(MongoDatabase database) {
		try {
			MongoCollection < Document > collection = database.getCollection("Clientes");
			MongoCursor < Document > collect = collection.find().iterator();
	
            while (collect.hasNext()) {
                Document doc = collect.next();
                ArrayList users = new ArrayList < > (doc.values());                      
                System.out.println( "ID: " + users.get(0) + "[ Nombre: " +  users.get(1) + ", Telefono: " +users.get(2) + "]");
            }
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void checkCollection(MongoDatabase database){
		Scanner input = new Scanner(System.in);

		try {
			MongoCollection < Document > collection = database.getCollection("Clientes");
			
			MongoCursor < Document > collect = collection.find().iterator();
			
			System.out.println("Añade el id o Nif del cliente que quieres consultar");
			String id = input.nextLine();
	
                while (collect.hasNext()) {

                    Document doc = collect.next();
                    ArrayList users = new ArrayList < > (doc.values());                    
                    
                    if(users.get(0).equals(id)) {
                    	System.out.println( "ID: " + users.get(0) + "[ Nombre: " +  users.get(1) + ", Telefono: " +users.get(2) + "]");
                    }                                      
                }		
                
		}catch (Exception e) {
			e.printStackTrace();
		}
	}



}
