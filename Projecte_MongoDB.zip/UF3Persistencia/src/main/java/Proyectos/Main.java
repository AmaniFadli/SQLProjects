package Proyectos;

import java.util.Scanner;

import org.bson.Document;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.MongoException;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.*;

public class Main {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String connectionString = "mongodb+srv://eladio:eladioalbertamani@UF3persistencia.1memkp2.mongodb.net/?retryWrites=true&w=majority";
        ServerApi serverApi = ServerApi.builder().version(ServerApiVersion.V1).build();
        MongoClientSettings settings = MongoClientSettings.builder().applyConnectionString(new ConnectionString(connectionString)).serverApi(serverApi).build();
        
        MongoDatabase database = null;
        
        // Create a new client and connect to the server
        try (MongoClient mongoClient = MongoClients.create(settings)) {
            try {
                // Send a ping to confirm a successful connection
                database = mongoClient.getDatabase("uf3persistencia");
                
                database.runCommand(new Document("ping", 1));
                System.out.println("Pinged your deployment. You successfully connected to MongoDB!");
                try {
                	database.createCollection("Clientes");
                }
                
                catch (MongoException e) {
                    database.getCollection("Clientes");
                }
                int rep = 0;
                
                do {
	                System.out.println("--- M E N U ---");
	        		System.out.println("1 --> Insertar Cliente");
	        		System.out.println("2 --> Eliminar Cliente");
	        		System.out.println("3 --> Lista de Clientes");
	        		System.out.println("4 --> Modificar Cliente");
	        		System.out.println("5 --> Consultar Cliente");
	        		
	        	
	        		int opcio = input.nextInt();
	        		
	        		switch(opcio) {
	        			case 1:
	        				Collection.insertDocument(database);
	        			break;
	        			
	        			case 2:
	        				Collection.deleteCollection(database);
	        			break;
	        			
	        			case 3:
	        				Collection.printCollections(database);
	        			break;
	        			
	        			case 4:
	        				Collection.updateDocument(database);
	        			break;
	        			
	        			case 5:
	        				Collection.checkCollection(database);
	        			break;
	        			default:
	        				System.out.println("Ocpión incorrecta. Elige una opción del menu");
	        			break;
	        		}
	        		System.out.println("Quieres volver al menú? 1-SI 2-NO" );
	        		rep = input.nextInt();
	        		
                }while(rep == 1);
            } 
            catch (MongoException e) {
                e.printStackTrace();
                database.getCollection("Clientes").drop();
            }
        }

	}

}
