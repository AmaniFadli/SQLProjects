package ProyectoB;

import java.util.Scanner;

import org.bson.Document;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.MongoException;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class Main {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String connectionString = "mongodb+srv://eladio:eladioalbertamani@UF3persistencia.1memkp2.mongodb.net/?retryWrites=true&w=majority";
        ServerApi serverApi = ServerApi.builder().version(ServerApiVersion.V1).build();
        MongoClientSettings settings = MongoClientSettings.builder().applyConnectionString(new ConnectionString(connectionString)).serverApi(serverApi).build();
        
        MongoDatabase database = null;
        
        // Create a new client and connect to the server
        try (MongoClient mongoClient = MongoClients.create(settings)) {
            try {
                // Send a ping to confirm a successful connection
                database = mongoClient.getDatabase("uf3persistencia");
                
                database.runCommand(new Document("ping", 1));
                System.out.println("Pinged your deployment. You successfully connected to MongoDB!");
                try {
                	database.createCollection("Videojuegos");
                }
                
                catch (MongoException e) {
                    database.getCollection("Videojuegos");
                }
                
                int rep = 0;

                do {

	                System.out.println("--- M E N U ---");
	                System.out.println("\"Exit\" per sortir de l'aplicatiu");
	                System.out.println("\"A\"  Insertar Videojuego");
	                System.out.println("\"B\"  Dar de baja viedojuego");
	                System.out.println("\"C1\" Mostrar Videojuegos");
	                System.out.println("\"C2\" Mostrar Juegos que no tienen existencia");
	                System.out.println("\"C3\" Mostrar 'Tipo de juegos' de los Videojuegos");
	                System.out.println("\"C4\" Mostrar Videojuegos con precio Superior al añadido");
	                System.out.println("\"C5\" Mostrar Videouego de un determinado \"diseñador\".");
	                System.out.println("\"C6\" Mostrar Comentarios de un Videojuego");
	                System.out.println("\"M\"  Modificar datos de un Videojuego ");
	                String opcio = input.next();

                switch(opcio) {

	                case "Exit":
	                break;
	                case "A":
	                	Collection.insertDocument(database);
	                break;
	                case "B":
	                	Collection.deleteVideogame(database);
	                break;      
	                case "C1":
	                	Collection.showVideogames(database);
	                break;	                
	                case "C2":
	                	Collection.MostrarJocsSenseExistencies(database);
	                break;
	                case "C3":
	                	Collection.printTipusJoc(database);
	                break;	
	                case "C4":
	                	Collection.printPreuSup(database);
	                break;
	                case "C5":
	                	Collection.searchDesigner(database);
	                break;
	                case "C6":
	                	Collection.printComentaris(database);
	                break;
	                case "M":
	                	Collection.updateDocument(database);
	                break;
	                default:
	                	System.out.println("Has elegit una opcio incorrecte");
	                break;
                }

                System.out.println("Quieres volver al menú? 1-SI 2-NO" );
                rep = input.nextInt();

                }while(rep == 1);     
            } 
            catch (MongoException e) {
                e.printStackTrace();
                database.getCollection("Clientes").drop();
            }
        }

	}

}
