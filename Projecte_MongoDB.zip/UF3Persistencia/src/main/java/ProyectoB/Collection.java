package ProyectoB;

import java.util.*;

import org.bson.Document;

import com.mongodb.MongoCommandException;
import com.mongodb.MongoException;
import com.mongodb.client.*;
import com.mongodb.client.model.Filters;

public class Collection {
	
	public static void insertDocument(MongoDatabase database) {
		Scanner input = new Scanner(System.in);
		
		try {
			String resp = null;
			boolean idRep = false;
			String id;
			System.out.println("Añadiendo Videojuego . . .");			
			MongoCollection <Document>  collection = database.getCollection("Videojuegos");
			
			do {
				System.out.println("Añade el codigo o identificador del Videojuego");
				 id = input.nextLine();
				 
				try {				
					MongoCursor < Document > collect = collection.find().iterator();

		            while (collect.hasNext()) {          			            	
		            	Document doc = collect.next();
		            	String idD = doc.getString("_id");
		            	
		            	if(idD.equals(id)) {		            		
		            		 System.out.println("Identificador repetido, porfavor, añade otro id");
		            		 idRep = true;
		            	}
		            	else {
		            		idRep = false;
		            	}
		            }
				}
				catch(MongoException e) {
					e.printStackTrace();
				}
			
			}while(idRep == true);
			
			System.out.println("Añade el nombre");
			String nom = input.nextLine();
			
			Document v1 = new Document("_id", id);
			v1.append("Nombre", nom);
			
			do {
				System.out.println("Opciones para añadir");
				System.out.println("1 -> Fabricante");
				System.out.println("2 -> Diseñador");
				System.out.println("3 -> Fecha de compra");
				System.out.println("4 -> Precio");
				System.out.println("5 -> Existencias/Stock");
				System.out.println("6 -> Tipo de juego");
				System.out.println("7 -> Numero de jugadores");
				System.out.println("8 -> Comentarios");
			
				int opcio = input.nextInt();
				
				switch(opcio) {
					case 1:
						System.out.println("Añade el Fabricante");
						String f = input.next();
						input.nextLine();
						v1.append("Fabricante", f);
					break;					
					case 2:
						
						System.out.println("Añade el nombre del Diseñador");
						String nD = input.next();
						
						System.out.println("Añade el numero de Telefono");
						int tel = input.nextInt();
						
						System.out.println("Añade el Email");
						String email = input.next();
						input.nextLine();

						Document d1 = new Document("_id" + " Nombre", nD);
						d1.append("Email", email);
						d1.append("Telefono", tel);
						
						v1.append("Diseñador", d1);
					break;					
					case 3: 
						System.out.println("Añade la fecha de compra(Ejemplo: 01/01/2001)");
						int any,  mes, dia;
						boolean rep = false;
						do {
							rep = false;
							System.out.print("Selecciona el año ");
						    any = input.nextInt();
						    if(any < 1950 || any > 2023) {
						    	System.out.println("El año és incorrecto, Introduce un año entre 1950 y 2023");
						    	rep = true;
						    }
						    else {
						    	rep = false;
						    }
						}while(rep);						
						do {
							rep = false;
							System.out.print("Selecciona el mes ");
							mes = input.nextInt();
							if(mes < 1 || mes > 12) {
								System.out.println("El mes és incorrecto, Introduce un mes entre 01 y 12");
								rep = true;
							}
							else {
								rep = false;
							}
						}while(rep);						
						do {
							rep = false;
							System.out.print("Selecciona el dia ");
							dia = input.nextInt();
							
							if(dia < 1 || dia > 31) {
								System.out.println("El dia és incorrecto, Introduce un dia entre 01 y 31");
								rep = true;
							}
							else if((mes == 4 || mes == 9 || mes == 6 || mes == 11) && dia == 31) {
								System.out.println("El dia y el mes no concuerdan, Introduce el dia correcto entre 01 y 30 ");
								rep = true;
							}
							else if(mes == 2 && dia > 28 && (any % 400 == 0)) {
								System.out.println("El dia, el mes y el año no concuerdan, si no es un año bisiesto, Introduce un dia entre 01 y 28, si lo es Intrroduce un dia entre 01 y 29");
								rep = true;
							}
							else {
								rep = false;
							}
						}while(rep);
						
						String fecha = dia + "/" + mes + "/" + any;
						v1.append("Fecha de compra", fecha);
					break;					
					case 4:
						int p;
						rep = false;
						do {
							System.out.println("Introduce el precio");
							p = input.nextInt();
							
							if(p < 0) {
								System.out.println("El precio no puede ser negativo, Introduce de nuevo el precio por encima de 0");
								rep = true;
							}
							else {
								rep = false;
							}
						}while(rep);
						v1.append("Precio", p);
					break;				
					case 5:
						int s;
						rep = false;
						do {
							System.out.println("Introduce la Existencia/Stock");
							s = input.nextInt();
							if(s < 0) {
								System.out.println("La Existencia/Stock no puede ser negativo, Introduce de nuevo la Existencias/Stock por encima de 0");
								 rep = true;
			            	}
			            	else {
			            		rep = false;
			            	}
						}while(rep);
						v1.append("Existencias/Stock", s);
					break;					
					case 6:						
						System.out.println("Que tipo de juego és?");
						System.out.println("1 -> Acción");
						System.out.println("2 -> Aventura");
						System.out.println("3 -> Estrategia");
						System.out.println("4 -> Arcade");
						System.out.println("5 -> Deportes");
						System.out.println("6 -> Simulación");
						System.out.println("7 -> Juegos de mesa");
						System.out.println("8 -> Juegos musicales");
						int o = input.nextInt();
						String tj;
						switch(o) {
							case 1:
								tj = "Acción";
								v1.append("Tipo de juego", tj);
							break;	
							case 2:
								tj = "Aventura";
								v1.append("Tipo de juego", tj);
							break;
							case 3:
								tj = "Estrategia";
								v1.append("Tipo de juego", tj);
							break;
							case 4:
								tj = "Arcade";
								v1.append("Tipo de juego", tj);
							break;
							case 5:
								tj = "Deportes";
								v1.append("Tipo de juego", tj);
							break;
							case 6:
								tj = "Simulación";
								v1.append("Tipo de juego", tj);
							break;
							case 7:
								tj = "Juegos de mesa";
								v1.append("Tipo de juego", tj);
							break;
							case 8:
								tj = "Juegos musicales";
								v1.append("Tipo de juego", tj);
							break;
							default:
		        				System.out.println("Ocpión incorrecta. Elige una opción del menu");
		        			break;
						}						
						System.out.println("'tipo de juego' añadido");						
					break;					
					case 7:
						int nj;
						rep = false;
						do {
							System.out.println("Introduce el numero de jugadores"); 
							nj = input.nextInt();
							if(nj < 0) {
								System.out.println("El  numero de jugadores no puede ser negativo, Introduce de nuevo el numero de jugadores por encima de 0");
								rep = true;
							}
							else {
								rep = false;
							}
						}while(rep);
						
						v1.append("Nº de jugadores", nj);
					break;					
					case 8:
						
						ArrayList<String> comentarios = new ArrayList<String>();
						int r = 0;
						do {
							input.nextLine();
							System.out.println("Introduce el comentario");
							String c = input.nextLine();
							
							comentarios.add(c);
							
							System.out.println("Quieres añadir otro comentario? 1-Si 2-NO");
							r = input.nextInt();

						}while(r == 1);
						
						v1.append("Comentarios", comentarios);
						
					break;	
					default:
        				System.out.println("Ocpión incorrecta. Elige una opción del menu");
        			break;
				}
				
				System.out.println("Quieres añadir otro complemento del Videojuego? (S/N)");
				resp = input.next();
				
			}while(resp.charAt(0) == 's' || resp.charAt(0) == 'S');	
			
			collection.insertOne(v1);
		}
		catch(MongoException e) {
			e.printStackTrace();
		}
	}
	
	public static void showVideogames(MongoDatabase database) {
		MongoCollection <Document> collection = database.getCollection("Videojuegos");
		
		try (MongoCursor<Document> mongoCursor = collection.find().iterator()){
			while (mongoCursor.hasNext()) {
				
				Document doc = mongoCursor.next();
				ArrayList videojuegos = new ArrayList<>(doc.values());
				System.out.print("Videojuego: ");
		
				for (int i=0; i < videojuegos.size(); i++) {
					System.out.print( videojuegos.get(i) + " | ");
				}
				System.out.println();
			}
		}
		catch(MongoException e) {
			e.printStackTrace();
		}
	}
	public static void printTipusJoc(MongoDatabase database) {
		try {
			MongoCollection < Document > collection = database.getCollection("Videojuegos");
			MongoCursor < Document > collect = collection.find().iterator();
	
			System.out.println("Tipo de juegos:");
            while (collect.hasNext()) {

                Document doc = collect.next();
               
                String tj = doc.getString("Tipo de juego");
                String nom = doc.getString("Nombre");
                
                System.out.println(tj + " /Juego -> " + nom);
            }
		}
		catch(MongoException e) {
			e.printStackTrace();
		}
	}
	
	public static void printPreuSup(MongoDatabase database) {
		Scanner input = new Scanner(System.in);
		try {
			MongoCollection < Document > collection = database.getCollection("Videojuegos");			
			MongoCursor < Document > collect = collection.find().iterator();
	
			System.out.println("Introduce el precio:");
			int precioS = input.nextInt();
			
            while (collect.hasNext()) {

                Document doc = collect.next();
                ArrayList users = new ArrayList < > (doc.values());
               
                int p = doc.getInteger("Precio");                      
                System.out.println("Videojuego: ");
                
                for(int i = 0; i < users.size(); i++) {               	
                	if(precioS < p) {                		
                		System.out.print(users.get(i) + " | ");
                	}
                }
            }
            System.out.println();
		}
		catch(MongoException e) {
			e.printStackTrace();
		}
	}
		
	public static void printComentaris(MongoDatabase database) {
		Scanner  input = new Scanner(System.in);
		MongoCollection < Document > collection = database.getCollection("Videojuegos");

		try {
		
			MongoCursor < Document > collect = collection.find().iterator();
			
			System.out.println("Introduce el nombre del videojuego");
			String nom = input.nextLine();
			
            while (collect.hasNext()) {          	
            	
            	Document doc = collect.next();
            	String nombre = doc.getString("Nombre");
            	
            	if(nombre.equals(nom)) {
	        		ArrayList <String>  coment = (ArrayList <String>)doc.get("Comentarios");
	                 
	                for(int i = 0; i < coment.size(); i++) {	                 
	                	System.out.println("- " + coment.get(i));
	                }
            	}
            }
		}
		catch(MongoException e) {
			e.printStackTrace();
		}
	}
	
	public static void searchDesigner(MongoDatabase database) {
		Scanner reader = new Scanner(System.in);
		
		String nombre;
		try {
			MongoCollection<Document> collection = database.getCollection("Videojuegos");	
			MongoCursor<Document> cursor = collection.find().iterator();
	
			System.out.println("Ingresa el nombre del diseñador: ");	
			nombre = reader.nextLine();
	
			while (cursor.hasNext()) {	
				Document doc = cursor.next();		
				Document designer = doc.get("Diseñador", Document.class);
		
				if (designer != null) {		
					String id = designer.getString("_id");		
					if(id != null) {			
						if (id.equals(nombre)) {					
							System.out.println("Nombre del diseñador: " + id);				
							System.out.println(doc.getString("Nombre"));				
						}			
					}	
				}
			}
		}
		catch(MongoException e) {
			e.printStackTrace();
		}
	}
	
	public static void MostrarJocsSenseExistencies(MongoDatabase database) {
		try{
			MongoCollection<Document> collection = database.getCollection("Videojuegos");
			MongoCursor<Document> cursor = collection.find().iterator();

			while (cursor.hasNext()) {
				Document doc = cursor.next();
			
				// Comprobar si el documento tiene la etiqueta "existencies"
				if(doc.containsKey("Existencias/Stock")) {
					// Obtener el valor de la etiqueta "existencies"
					int existencies = doc.getInteger("Existencias/Stock", 0);					
					// Comprobar si existencies es mayor que 0
					System.out.println(existencies);
					if(existencies > 0) {		
						System.out.println("Si que hay existencias");
					} 
					else {
						System.out.println("El videojuego " + doc.getString("Nombre") + " no tiene existencias.");
					}
				} 
				else {
					System.out.println("El videojuego " + doc.getString("Nombre") + " no contiene la etiqueta existencias.");
				}
			}
			
		} 
		catch (MongoException e) {
			e.printStackTrace();
		}
	}
	
	public static void updateDocument(MongoDatabase database) {       
		Scanner input = new Scanner(System.in);
		
		try {
	        MongoCollection < Document > collection = database.getCollection("Videojuegos");	        	   
	        System.out.println("Modificacion iniciada ...");
	        
	        System.out.println("Selecciona el identificador del Videojuego que quieres modificar");
	        String id = input.nextLine();
	        System.out.println();
	        System.out.println("Que quieres modiciar?:");
	        System.out.println("1 -> Numero de jugadores");
	        System.out.println("2 -> Precio");
	        System.out.println("3 -> Existencia/Stock");
	        System.out.println("4 -> Tipo de Juego");
	        
	        int opcio = input.nextInt();
	        
	        switch(opcio) {
	        	case 1:
	        		System.out.print("Inserta el nuevo numero de jugadores: ");
		        	int num = input.nextInt();
		        	 
		        	collection.updateOne(new Document("_id", id),new Document("$set", new Document("Nº de jugadores", num)));
	        	break;
	        	case 2:
	        		System.out.print("Inserta el nuevo precio: ");
		        	int preu = input.nextInt();
		        	 
		        	collection.updateOne(new Document("_id", id),new Document("$set", new Document("Precio", preu)));
		        break;
	        	case 3:
	        		System.out.print("Inserta el nuevo Existencias/Stock: ");
		        	int s = input.nextInt();
		        	 
		        	collection.updateOne(new Document("_id", id),new Document("$set", new Document("Existencias/Stock", s)));
		        break;
	        	case 4:
	        		
		        	System.out.println("Inserta el nuevo tipo de juego, elije una opción");
					System.out.println("1 -> Acción");
					System.out.println("2 -> Aventura");
					System.out.println("3 -> Estrategia");
					System.out.println("4 -> Arcade");
					System.out.println("5 -> Deportes");
					System.out.println("6 -> Simulación");
					System.out.println("7 -> Juegos de mesa");
					System.out.println("8 -> Juegos musicales");
					int o = input.nextInt();
					String tj;
					switch(o) {
						case 1:
							tj = "Acción";
							collection.updateOne(new Document("_id", id),new Document("$set", new Document("Tipo de juego", tj)));
						break;	
						case 2:
							tj = "Aventura";
							collection.updateOne(new Document("_id", id),new Document("$set", new Document("Tipo de juego", tj)));
						break;
						case 3:
							tj = "Estrategia";
							collection.updateOne(new Document("_id", id),new Document("$set", new Document("Tipo de juego", tj)));
						break;
						case 4:
							tj = "Arcade";
							collection.updateOne(new Document("_id", id),new Document("$set", new Document("Tipo de juego", tj)));
						break;
						case 5:
							tj = "Deportes";
							collection.updateOne(new Document("_id", id),new Document("$set", new Document("Tipo de juego", tj)));
						break;
						case 6:
							tj = "Simulación";
							collection.updateOne(new Document("_id", id),new Document("$set", new Document("Tipo de juego", tj)));
						break;
						case 7:
							tj = "Juegos de mesa";
							collection.updateOne(new Document("_id", id),new Document("$set", new Document("Tipo de juego", tj)));
						break;
						case 8:
							tj = "Juegos musicales";
							collection.updateOne(new Document("_id", id),new Document("$set", new Document("Tipo de juego", tj)));
						break;
						default:
	        				System.out.println("Ocpión incorrecta. Elige una opción del menu");
	        			break;
					}
					
					System.out.println("'tipo de juego' añadido");  	
		        break;
	        	default:
    				System.out.println("Ocpión incorrecta. Elige una opción del menu");
    			break;
	        }	    
	        System.out.println("Modificacion terminada");
	        System.out.println();
		}
		catch ( MongoException e) {
			System.out.println("!!!!Error en la modificación!!!!");
            e . printStackTrace();
        }
	}
	public static void deleteVideogame(MongoDatabase database) {
		Scanner input = new Scanner(System.in);
		
		try {
			MongoCollection < Document > collection = database.getCollection("Videojuegos");	
			
			System.out.println("Escribe el id del videojuego que quieres eliminar.");	
			String id = input.nextLine();
			
			collection.deleteOne(Filters.eq("_id", id));	
			System.out.println("Document deleted successfully...");
		} 
		catch (Exception e) {
			e.getStackTrace();
		}
	}
}


