package UF4_Practica2;

import java.util.*;
import java.sql.*;

public class Main {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Con que quieres acceder a la base de datos: ");
		System.out.println("1 --> Hibernate");
		System.out.println("2 --> Persistencia");
		int op = input.nextInt();
		
		PersistenciaInterfice per = null;
		String rep;
		
		if(op == 1) {
			per = new Hibernate();
		}
		else if (op == 2){
			per = new Persistencia();
		}
		
		do {
			System.out.println("--- M E N Ú ---");
			System.out.println("1 --> Dar de Alta Pregunta");
			System.out.println("2 --> Consultar Pregunta por Tematica");
			System.out.println("3 --> Dar de Baja Pregunt");
			System.out.println("4 --> Exit");
			
			Pregunta p;
			List <Pregunta> preguntas;
			input.nextLine();
			int opcio = input.nextInt();
			
			switch(opcio) {
			
				case 1:
					System.out.println();
					System.out.println("Rellena el formulario:");
					System.out.print("1 -> Enunciado pregunta:");
					input.nextLine();
					String e = input.nextLine();
					
					System.out.print("2 -> Respuesta A: ");
					String rA = input.nextLine();
					
					System.out.print("3 -> Respuesta B: ");
					String rB = input.nextLine();
					
					System.out.print("4 -> Respuesta C: ");
					String rC = input.nextLine();
					
					System.out.print("5 -> Respuesta D: ");
					String rD = input.nextLine();
					String respC;
					int r = 0;
					do {		
						System.out.print("6 -> Respuesta correcta (A/B/C o D): ");
						respC = input.nextLine();
						if(respC.equalsIgnoreCase("A") || respC.equalsIgnoreCase("B") || respC.equalsIgnoreCase("C") || respC.equalsIgnoreCase("D")) {
							r = 1;
						}
						else {
							System.out.println("Error, Introduce de nuevo la Respuesta Correcta");
						}
					}while(r == 0);
					
					System.out.print("7 -> Tematica: ");
					String t = input.nextLine();
					
					p = new Pregunta(e,rA,rB,rC,rD,respC,t);
					per.insertPregunta(p);
					
					System.out.println("¡¡Pregunta introducida con Exito!!");
				break;
				case 2:
					System.out.println("Introduce la tematica");
					input.nextLine();
					String tem = input.nextLine();
					
					preguntas = per.consultaPreguntesTematica(tem);
					
					for(int i = 0; i < preguntas.size(); i++) {
						p = preguntas.get(i);
						
						System.out.println("Enunciado: " + p.getPregunta());
						System.out.println("Respuesta A : " + p.getrA());
						System.out.println("Respuesta B : " + p.getrB());
						System.out.println("Respuesta C : " + p.getrC());
						System.out.println("Respuesta D : " + p.getrD());
						System.out.println("Respuesta Correcta: " + p.getRespC());
						System.out.println("Tematica Seleccionada: " + p.getTematica());
						System.out.println();
					}
				break;
				case 3:
					preguntas = per.consultaPreguntes();
	
					System.out.println("Inserta el ID de la pregunta que quieres dar de baja. A continuación té enseñaré la lista");
					for(int i = 0; i < preguntas.size(); i++) {
						p = preguntas.get(i);
						
						System.out.println("ID: " + (i+1));
						System.out.println("Enunciado: " + p.getPregunta());
						System.out.println("Respuesta A : " + p.getrA());
						System.out.println("Respuesta B : " + p.getrB());
						System.out.println("Respuesta C : " + p.getrC());
						System.out.println("Respuesta D : " + p.getrD());
						System.out.println("Respuesta Correcta: " + p.getRespC());
						System.out.println("Tematica Seleccionada: " + p.getTematica());
						System.out.println();
					}
					
					System.out.println("Introduce el ID de la prgunta");
					int id = input.nextInt();
					
					per.deletePregunta(id);
					System.out.println("¡¡Pregunta dada de Baja con Exito!!");
				break;
				default : System.out.println("Error Numero mal seleccionado");
				break;
			}
			
			System.out.println("Quieres volver al menu? (S/N)");
			input.nextLine();
			rep = input.nextLine();
			
		}while(rep.charAt(0) == 's' || rep.charAt(0) == 'S');
		
		System.out.println("Saliendo del programa. . .");
	}

}
