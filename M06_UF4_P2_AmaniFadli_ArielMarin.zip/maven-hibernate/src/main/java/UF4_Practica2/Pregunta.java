package UF4_Practica2;

public class Pregunta {

	private String pregunta;
	private String tematica;
	private String rA;
	private String rB;
	private String rC;
	private String rD;
	private String respC;
	
	public Pregunta() {
	}

	public Pregunta(String pregunta, String rA, String rB, String rC, String rD, String respC, String tematica) {
		this.pregunta = pregunta;
		this.rA = rA;
		this.rB = rB;
		this.rC = rC;
		this.rD = rD;
		this.respC = respC;
		this.tematica = tematica;
	}

	public String getPregunta() {
		return pregunta;
	}

	public void setPregunta(String pregunta) {
		this.pregunta = pregunta;
	}

	public String getrA() {
		return rA;
	}

	public void setrA(String rA) {
		this.rA = rA;
	}

	public String getrB() {
		return rB;
	}

	public void setrB(String rB) {
		this.rB = rB;
	}

	public String getrC() {
		return rC;
	}

	public void setrC(String rC) {
		this.rC = rC;
	}

	public String getrD() {
		return rD;
	}

	public void setrD(String rD) {
		this.rD = rD;
	}

	public String getRespC() {
		return respC;
	}

	public void setRespC(String respC) {
		this.respC = respC;
	}

	public String getTematica() {
		return tematica;
	}

	public void setTematica(String tematica) {
		this.tematica = tematica;
	}

	@Override
	public String toString() {
		return "Pregunta [pregunta=" + pregunta + ", rA=" + rA + ", rB=" + rB + ", rC=" + rC + ", rD=" + rD + ", respC="
				+ respC + "]";
	}
	
}
