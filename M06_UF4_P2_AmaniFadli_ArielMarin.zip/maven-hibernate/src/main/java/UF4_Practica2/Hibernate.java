package UF4_Practica2;

import java.util.List;
import java.util.Properties;

import org.hibernate.*;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.service.ServiceRegistry;

public class Hibernate implements PersistenciaInterfice{
	
	public SessionFactory establirConnexio() {
	   SessionFactory sessionFactory = null;
	   if (sessionFactory ==  null ) {
           try {
               Configuration configuration =  new  Configuration ();

              // Hibernate settings equivalent to hibernate.cfg.xml's properties 
              Properties settings =  new  Properties ();
              settings . put( Environment . DRIVER , " com.mysql.cj.jdbc.Driver " );
              settings . put( Environment . URL , " jdbc:mysql://labs.inspedralbes.cat/a22amafaddok_hibernate?useSSL=false " );
              settings . put( Environment . USER , "a22amafaddok_Amani12" );
              settings . put( Environment . PASS , "Piscina12" );
              settings . put( Environment . SHOW_SQL , " true " );

              settings . put( Environment . CURRENT_SESSION_CONTEXT_CLASS , " thread " );

              settings . put( Environment . HBM2DDL_AUTO , " create-drop " );

              configuration . setProperties(settings);

              configuration . addAnnotatedClass( Pregunta . class);

              ServiceRegistry serviceRegistry =  new  StandardServiceRegistryBuilder ()
                  .applySettings(configuration . getProperties()) . build();

              sessionFactory = configuration . buildSessionFactory(serviceRegistry);
          } catch ( Exception e) {
              e . printStackTrace();
          }
      }
      return sessionFactory;
	}
	
	public void insertPregunta(Pregunta pregunta) {
		Transaction transaction =  null ;
        
       try (Session session =  establirConnexio().openSession()) {
            // start a transaction 
           transaction = session . beginTransaction();
           
           // save the student object 
           session.save(pregunta);
           
           // commit transaction 
           transaction.commit();
       } catch ( Exception e) {
            if (transaction !=  null ) {
               transaction.rollback();
           }
           e.printStackTrace();
       }
	}
	
	public void deletePregunta(int idPregunta) {
		Transaction tx = null;
	      
		try(Session session = establirConnexio().openSession()) {
		   tx = session.beginTransaction();
		     
		   Pregunta p = session.get(Pregunta.class, idPregunta); 
		   session.delete(p);
		     
		   tx.commit();
		} 
		catch (Exception e) {
		    if (tx!=null) tx.rollback();
		   e.printStackTrace(); 
		} 
	}
	
	public List<Pregunta> consultaPreguntes(){
		try ( Session session =  establirConnexio().openSession()) {
            return session.createQuery( " from CARTAS " , Pregunta.class).list();
       }
	}
	
	public List<Pregunta> consultaPreguntesTematica(String tematica){
		try ( Session session =  establirConnexio().openSession()) {
            return session.createQuery( " from CARTAS WHERE TEMATICA =" + tematica , Pregunta.class).list();
       }
	}
}
