package UF4_Practica2;

import java.sql.*;
import java.util.*;

public class Persistencia implements PersistenciaInterfice{
	
	public static Connection establirConnexio() {
		
		String web = "labs.inspedralbes.cat"; 
		String nomBD = "a22amafaddok_uf4";
		String Port = ":3306/";  
		String url  = "jdbc:mariadb://" + web + Port + nomBD; 
		String usuari = "a22amafaddok_AM";
		String pswd = "Piscina12";
		Connection connexio = null;
		
		try {
			connexio = DriverManager.getConnection(url, usuari, pswd);
			System.out.println("S'ha establert connexió amb BD");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}		
		return connexio;
	}
	
	public static void tencarConnexio(Connection con) {
		try {
			con.close();
		}
		catch(SQLException e) {		
			e.printStackTrace();
		}
		
	}
	
	public void insertPregunta(Pregunta pregunta) {
		
		Connection con = establirConnexio();
		try {
			PreparedStatement statement = con.prepareStatement("""
		          INSERT INTO CARTAS (ID_PREGUNTA,PREGUNTA,TEMATICA,RA,RB,RC,RD,RESP_CORRECTA)
		          VALUES (NULL,?, ?, ?, ?, ?, ?, ?)
		          """);
			{
				
		    statement.setString(1, pregunta.getPregunta());
		    
		    statement.setString(2, pregunta.getTematica());
		    
		    statement.setString(3, pregunta.getrA());
		    
		    statement.setString(4, pregunta.getrB());
		    
		    statement.setString(5, pregunta.getrC());
		    
		    statement.setString(6, pregunta.getrD());
		    
		    statement.setString(7, pregunta.getRespC());

		    int rowsInserted = statement.executeUpdate(); 
		    
		    if (rowsInserted > 0)
		       con.commit();  		    
			}
		tencarConnexio(con);
	    }
	       catch (SQLException e) {	
			e.printStackTrace();
		}
	}
		
	public void deletePregunta(int idPregunta) {
		Connection con = establirConnexio();
		try {
			PreparedStatement statement = con.prepareStatement("""
		          DELETE FROM CARTAS
		          WHERE ID_PREGUNTA = ?
		          """);
			{
				
		    statement.setInt(1, idPregunta);

		    int rowsDelete = statement.executeUpdate(); 
		    
		    if (rowsDelete > 0)
		       con.commit();  		    
			}
		tencarConnexio(con);
	    }
	       catch (SQLException e) {	
			e.printStackTrace();
		}
	}
    public ArrayList<Pregunta> consultaPreguntes() {
    	Connection con = establirConnexio();
		ArrayList<Pregunta> preguntas = new ArrayList<Pregunta>();
		PreparedStatement statement;
		
		try{
		       statement = con.prepareStatement("""
		            SELECT PREGUNTA,RA,RB,RC,RD,RESP_CORRECTA,TEMATICA
		            FROM CARTAS
		      
		        """);
		       
		    		   
		       ResultSet resultSet = statement.executeQuery();
		       
		       while (resultSet.next()) {
		           String val1 = resultSet.getString(1);
		           String val2 = resultSet.getString(2);
		           String val3 = resultSet.getString(3);
		           String val4 = resultSet.getString(4);
		           String val5 = resultSet.getString(5);
		           String val6 = resultSet.getString(6);
		           String val7 = resultSet.getString(7);
		           
		           
		          Pregunta pregunta = new Pregunta(val1, val2, val3, val4, val5,val6,val7);
		          
		          preguntas.add(pregunta);
		       }
		       statement.close();
		       tencarConnexio(con);
		   }
		catch(SQLException e) {		
			e.printStackTrace();
		}
		
		return preguntas;
	}
	
	public List<Pregunta> consultaPreguntesTematica(String tematica) {
		
		Connection con = establirConnexio();
		List<Pregunta> preguntas = new ArrayList<Pregunta>();
		PreparedStatement statement;
		
		try{
		       statement = con.prepareStatement("""
		            SELECT PREGUNTA,RA,RB,RC,RD,RESP_CORRECTA,TEMATICA
		            FROM CARTAS
		            WHERE TEMATICA = ?
		      
		        """);
		       statement.setString(1, tematica);
		    		   
		       ResultSet resultSet = statement.executeQuery();
		       
		       while (resultSet.next()) {
		           String val1 = resultSet.getString(1);
		           String val2 = resultSet.getString(2);
		           String val3 = resultSet.getString(3);
		           String val4 = resultSet.getString(4);
		           String val5 = resultSet.getString(5);
		           String val6 = resultSet.getString(6);
		           String val7 = resultSet.getString(7);
		           
		           
		          Pregunta pregunta = new Pregunta(val1, val2, val3, val4, val5,val6,val7);
		          
		          preguntas.add(pregunta);
		       }
		       statement.close();
		       tencarConnexio(con);
		   }
		catch(SQLException e) {		
			e.printStackTrace();
		}
		
		return preguntas;
	}
	
	// extra :)
	public static void updatePregunta(int idPreg) {
		Scanner input = new Scanner(System.in);
		
		Connection con = establirConnexio();
		PreparedStatement statement;
		input.nextLine();
		System.out.println("QUE QUIERES MODIFICAR DE LA PREGUNTA?");
		System.out.println("1 --> Enunciado");
		System.out.println("2 --> Respuesta A");
		System.out.println("3 --> Respuesta B");
		System.out.println("4 --> Respuesta C");
		System.out.println("5 --> Respuesta D");
		System.out.println("6 --> Respuesta Correcta");
		System.out.println("7 --> Tematica");
		int opcio = input.nextInt();
		
		switch(opcio) {
			case 1:
				System.out.println();
				System.out.println("Introduce el nuevo enunciado:");
				String en = input.nextLine();
				try{
				       statement = con.prepareStatement("""
				            UPDATE CARTAS
				            SET (PREGUNTA = ?)
				            WHERE (ID_PREGUNTA = ?)
				            
				      
				        """);
				       statement.setString(1,en);
				       statement.setInt(2, idPreg);
				    		   
				       ResultSet resultSet = statement.executeQuery();
				       
				       int rowsUpdate = statement.executeUpdate(); 
					    
					    if (rowsUpdate > 0) {
					       con.commit();  		    
						}
				       statement.close();
				   }
				catch(SQLException e) {		
					e.printStackTrace();
				}
			break;
			case 2:
				System.out.println();
				System.out.println("Introduce la nueva Respuesta A:");
				String rA = input.nextLine();
				try{
				       statement = con.prepareStatement("""
				            UPDATE CARTAS
				            SET (RA = ?)
				            WHERE (ID_PREGUNTA = ?)
				            
				      
				        """);
				       statement.setString(1,rA);
				       statement.setInt(2, idPreg);
				    		   
				       ResultSet resultSet = statement.executeQuery();
				       
				       int rowsUpdate = statement.executeUpdate(); 
					    
					    if (rowsUpdate > 0) {
					       con.commit();  		    
						}
				       statement.close();
				   }
				catch(SQLException e) {		
					e.printStackTrace();
				}
			break;
			case 3:
				System.out.println();
				System.out.println("Introduce la nueva Respuesta B :");
				String rB = input.nextLine();
				try{
				       statement = con.prepareStatement("""
				            UPDATE CARTAS
				            SET (RB = ?)
				            WHERE (ID_PREGUNTA = ?)
				            
				      
				        """);
				       statement.setString(1,rB);
				       statement.setInt(2, idPreg);
				    		   
				       ResultSet resultSet = statement.executeQuery();
				       
				       int rowsUpdate = statement.executeUpdate(); 
					    
					    if (rowsUpdate > 0) {
					       con.commit();  		    
						}
				       statement.close();
				   }
				catch(SQLException e) {		
					e.printStackTrace();
				}
			break;
			case 4:
				System.out.println();
				System.out.println("Introduce la nueva Respuesta C :");
				String rC = input.nextLine();
				try{
				       statement = con.prepareStatement("""
				            UPDATE CARTAS
				            SET (RC = ?)
				            WHERE (ID_PREGUNTA = ?)
				            
				      
				        """);
				       statement.setString(1,rC);
				       statement.setInt(2, idPreg);
				    		   
				       ResultSet resultSet = statement.executeQuery();
				       
				       int rowsUpdate = statement.executeUpdate(); 
					    
					    if (rowsUpdate > 0) {
					       con.commit();  		    
						}
				       statement.close();
				   }
				catch(SQLException e) {		
					e.printStackTrace();
				}
			break;
			case 5:
				System.out.println();
				System.out.println("Introduce la nueva Respuesta D :");
				String rD = input.nextLine();
				try{
				       statement = con.prepareStatement("""
				            UPDATE CARTAS
				            SET (RD = ?)
				            WHERE (ID_PREGUNTA = ?)
				            
				      
				        """);
				       statement.setString(1,rD);
				       statement.setInt(2, idPreg);
				    		   
				       ResultSet resultSet = statement.executeQuery();
				       
				       int rowsUpdate = statement.executeUpdate(); 
					    
					    if (rowsUpdate > 0) {
					       con.commit();  		    
						}
				       statement.close();
				   }
				catch(SQLException e) {		
					e.printStackTrace();
				}
			break;
			case 6: 
				System.out.println();
				System.out.println("Introduce la nueva Respuesta Correcta :");
				String resp = input.nextLine();
				try{
				       statement = con.prepareStatement("""
				            UPDATE CARTAS
				            SET (RESP_CORRECTA = ?)
				            WHERE (ID_PREGUNTA = ?)
				            
				      
				        """);
				       statement.setString(1,resp);
				       statement.setInt(2, idPreg);
				    		   
				       ResultSet resultSet = statement.executeQuery();
				       
				       int rowsUpdate = statement.executeUpdate(); 
					    
					    if (rowsUpdate > 0) {
					       con.commit();  		    
						}
				       statement.close();
				   }
				catch(SQLException e) {		
					e.printStackTrace();
				}
			break;
			case 7:
				System.out.println();
				System.out.println("Introduce la nueva Tematica:");
				String t = input.nextLine();
				try{
				       statement = con.prepareStatement("""
				            UPDATE CARTAS
				            SET (TEMATICA = ?)
				            WHERE (ID_PREGUNTA = ?)
				            
				      
				        """);
				       statement.setString(1,t);
				       statement.setInt(2, idPreg);
				    		   
				       ResultSet resultSet = statement.executeQuery();
				       
				       int rowsUpdate = statement.executeUpdate(); 
					    
					    if (rowsUpdate > 0) {
					       con.commit();  		    
						}
				       statement.close();
				   }
				catch(SQLException e) {		
					e.printStackTrace();
				}
			break;	
		}
		tencarConnexio(con);
	}

}
