package UF4_Practica2;


import java.util.List;

public interface PersistenciaInterfice {

	public void insertPregunta(Pregunta pregunta);
	
	// Con la conexión abierta, insertamos una nueva pregunta. Utilizaremos la clase Pregunta y añadiremos el nuevo objeto a la base de datos elegida.
	
	public void deletePregunta(int idPregunta);
	//Con la conexión abierta, eliminaremos una pregunta de la base de datos utilizando su id referente para poder encontarla.
	
	public List<Pregunta> consultaPreguntes();
	//Con la conexión abierta, devolveremos una lista con todas  las peguntas que estan añadidas en la base de datos
	
	public List<Pregunta> consultaPreguntesTematica(String tematica);
	//Con la conexión abierta, devolveremos una lista con todas las preguntas que tengan como tematica el parametro recogido;
	
}
